﻿namespace pokus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.buttonequals = new System.Windows.Forms.Button();
            this.buttonpoint = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttondiv = new System.Windows.Forms.Button();
            this.buttonplus = new System.Windows.Forms.Button();
            this.buttonsub = new System.Windows.Forms.Button();
            this.buttonmul = new System.Windows.Forms.Button();
            this.buttonpower = new System.Windows.Forms.Button();
            this.buttonfact = new System.Windows.Forms.Button();
            this.buttonabs = new System.Windows.Forms.Button();
            this.buttonce = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.root = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(11, 298);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 60);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.toolTip1.SetToolTip(this.button1, "number key");
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(97, 298);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 60);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.toolTip1.SetToolTip(this.button2, "number key");
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(181, 298);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 60);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.toolTip1.SetToolTip(this.button3, "number key");
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button_Click);
            // 
            // result
            // 
            this.result.AcceptsReturn = true;
            this.result.AcceptsTab = true;
            this.result.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.result.ForeColor = System.Drawing.Color.DimGray;
            this.result.Location = new System.Drawing.Point(11, 12);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(489, 98);
            this.result.TabIndex = 3;
            this.result.Text = "0";
            this.result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(181, 218);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(65, 60);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.toolTip1.SetToolTip(this.button6, "number key");
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(97, 218);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(65, 60);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.toolTip1.SetToolTip(this.button5, "number key");
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(12, 218);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(65, 60);
            this.button4.TabIndex = 4;
            this.button4.Text = "4";
            this.toolTip1.SetToolTip(this.button4, "number key");
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(181, 138);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(65, 60);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.toolTip1.SetToolTip(this.button9, "number key");
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(97, 136);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(65, 60);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.toolTip1.SetToolTip(this.button8, "number key");
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button_Click);
            // 
            // buttonequals
            // 
            this.buttonequals.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonequals.FlatAppearance.BorderSize = 0;
            this.buttonequals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonequals.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonequals.ForeColor = System.Drawing.Color.White;
            this.buttonequals.Location = new System.Drawing.Point(436, 296);
            this.buttonequals.Margin = new System.Windows.Forms.Padding(2);
            this.buttonequals.Name = "buttonequals";
            this.buttonequals.Size = new System.Drawing.Size(65, 142);
            this.buttonequals.TabIndex = 12;
            this.buttonequals.Text = "=";
            this.toolTip1.SetToolTip(this.buttonequals, "Performs selected operations with slected number");
            this.buttonequals.UseVisualStyleBackColor = false;
            this.buttonequals.Click += new System.EventHandler(this.equals_Click);
            // 
            // buttonpoint
            // 
            this.buttonpoint.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonpoint.FlatAppearance.BorderSize = 0;
            this.buttonpoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonpoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonpoint.ForeColor = System.Drawing.Color.White;
            this.buttonpoint.Location = new System.Drawing.Point(97, 378);
            this.buttonpoint.Margin = new System.Windows.Forms.Padding(2);
            this.buttonpoint.Name = "buttonpoint";
            this.buttonpoint.Size = new System.Drawing.Size(65, 60);
            this.buttonpoint.TabIndex = 11;
            this.buttonpoint.Text = ",";
            this.toolTip1.SetToolTip(this.buttonpoint, "Decimal point");
            this.buttonpoint.UseVisualStyleBackColor = false;
            this.buttonpoint.Click += new System.EventHandler(this.button_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button0.FlatAppearance.BorderSize = 0;
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button0.ForeColor = System.Drawing.Color.White;
            this.button0.Location = new System.Drawing.Point(14, 378);
            this.button0.Margin = new System.Windows.Forms.Padding(2);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(65, 60);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.toolTip1.SetToolTip(this.button0, "number key");
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button_Click);
            // 
            // buttondiv
            // 
            this.buttondiv.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttondiv.FlatAppearance.BorderSize = 0;
            this.buttondiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttondiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttondiv.ForeColor = System.Drawing.Color.White;
            this.buttondiv.Location = new System.Drawing.Point(265, 136);
            this.buttondiv.Margin = new System.Windows.Forms.Padding(2);
            this.buttondiv.Name = "buttondiv";
            this.buttondiv.Size = new System.Drawing.Size(65, 60);
            this.buttondiv.TabIndex = 16;
            this.buttondiv.Text = "/";
            this.toolTip1.SetToolTip(this.buttondiv, "Divide");
            this.buttondiv.UseVisualStyleBackColor = false;
            this.buttondiv.Click += new System.EventHandler(this.operator_pressed);
            // 
            // buttonplus
            // 
            this.buttonplus.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonplus.FlatAppearance.BorderSize = 0;
            this.buttonplus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonplus.ForeColor = System.Drawing.Color.White;
            this.buttonplus.Location = new System.Drawing.Point(181, 378);
            this.buttonplus.Margin = new System.Windows.Forms.Padding(2);
            this.buttonplus.Name = "buttonplus";
            this.buttonplus.Size = new System.Drawing.Size(149, 60);
            this.buttonplus.TabIndex = 15;
            this.buttonplus.Text = "+";
            this.toolTip1.SetToolTip(this.buttonplus, "Add");
            this.buttonplus.UseVisualStyleBackColor = false;
            this.buttonplus.Click += new System.EventHandler(this.operator_pressed);
            // 
            // buttonsub
            // 
            this.buttonsub.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonsub.FlatAppearance.BorderSize = 0;
            this.buttonsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonsub.ForeColor = System.Drawing.Color.White;
            this.buttonsub.Location = new System.Drawing.Point(265, 296);
            this.buttonsub.Margin = new System.Windows.Forms.Padding(2);
            this.buttonsub.Name = "buttonsub";
            this.buttonsub.Size = new System.Drawing.Size(65, 60);
            this.buttonsub.TabIndex = 14;
            this.buttonsub.Text = "-";
            this.toolTip1.SetToolTip(this.buttonsub, "Subtract");
            this.buttonsub.UseVisualStyleBackColor = false;
            this.buttonsub.Click += new System.EventHandler(this.operator_pressed);
            // 
            // buttonmul
            // 
            this.buttonmul.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonmul.FlatAppearance.BorderSize = 0;
            this.buttonmul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonmul.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonmul.ForeColor = System.Drawing.Color.White;
            this.buttonmul.Location = new System.Drawing.Point(265, 218);
            this.buttonmul.Margin = new System.Windows.Forms.Padding(2);
            this.buttonmul.Name = "buttonmul";
            this.buttonmul.Size = new System.Drawing.Size(65, 60);
            this.buttonmul.TabIndex = 13;
            this.buttonmul.Text = "*";
            this.toolTip1.SetToolTip(this.buttonmul, "Multiply");
            this.buttonmul.UseVisualStyleBackColor = false;
            this.buttonmul.Click += new System.EventHandler(this.operator_pressed);
            // 
            // buttonpower
            // 
            this.buttonpower.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonpower.FlatAppearance.BorderSize = 0;
            this.buttonpower.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonpower.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonpower.ForeColor = System.Drawing.Color.White;
            this.buttonpower.Location = new System.Drawing.Point(347, 378);
            this.buttonpower.Margin = new System.Windows.Forms.Padding(2);
            this.buttonpower.Name = "buttonpower";
            this.buttonpower.Size = new System.Drawing.Size(65, 60);
            this.buttonpower.TabIndex = 17;
            this.buttonpower.Text = "xʸ";
            this.toolTip1.SetToolTip(this.buttonpower, "Raises x to power of y(First numbers selected is x)");
            this.buttonpower.UseVisualStyleBackColor = false;
            this.buttonpower.Click += new System.EventHandler(this.operator_pressed);
            // 
            // buttonfact
            // 
            this.buttonfact.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonfact.FlatAppearance.BorderSize = 0;
            this.buttonfact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonfact.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonfact.ForeColor = System.Drawing.Color.White;
            this.buttonfact.Location = new System.Drawing.Point(347, 218);
            this.buttonfact.Margin = new System.Windows.Forms.Padding(2);
            this.buttonfact.Name = "buttonfact";
            this.buttonfact.Size = new System.Drawing.Size(65, 60);
            this.buttonfact.TabIndex = 18;
            this.buttonfact.Text = "x!";
            this.toolTip1.SetToolTip(this.buttonfact, "Factorial (only for posititve integer)");
            this.buttonfact.UseVisualStyleBackColor = false;
            this.buttonfact.Click += new System.EventHandler(this.button_fact);
            // 
            // buttonabs
            // 
            this.buttonabs.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonabs.FlatAppearance.BorderSize = 0;
            this.buttonabs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonabs.ForeColor = System.Drawing.Color.White;
            this.buttonabs.Location = new System.Drawing.Point(347, 136);
            this.buttonabs.Margin = new System.Windows.Forms.Padding(2);
            this.buttonabs.Name = "buttonabs";
            this.buttonabs.Size = new System.Drawing.Size(65, 60);
            this.buttonabs.TabIndex = 19;
            this.buttonabs.Text = "|x|";
            this.toolTip1.SetToolTip(this.buttonabs, "Absolute  value");
            this.buttonabs.UseVisualStyleBackColor = false;
            this.buttonabs.Click += new System.EventHandler(this.button_abs_Click);
            // 
            // buttonce
            // 
            this.buttonce.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonce.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonce.FlatAppearance.BorderSize = 0;
            this.buttonce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonce.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonce.ForeColor = System.Drawing.Color.White;
            this.buttonce.Location = new System.Drawing.Point(436, 136);
            this.buttonce.Margin = new System.Windows.Forms.Padding(2);
            this.buttonce.Name = "buttonce";
            this.buttonce.Size = new System.Drawing.Size(65, 60);
            this.buttonce.TabIndex = 20;
            this.buttonce.Text = "C";
            this.toolTip1.SetToolTip(this.buttonce, "Clear");
            this.buttonce.UseVisualStyleBackColor = false;
            this.buttonce.Click += new System.EventHandler(this.buttonc_click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(12, 136);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(65, 60);
            this.button7.TabIndex = 21;
            this.button7.Text = "7";
            this.toolTip1.SetToolTip(this.button7, "number key");
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(347, 110);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(0, 0);
            this.button10.TabIndex = 22;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(436, 218);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(65, 60);
            this.button11.TabIndex = 23;
            this.button11.Text = "CE";
            this.toolTip1.SetToolTip(this.button11, "Clear everything");
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.buttonce_Click);
            // 
            // root
            // 
            this.root.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.root.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.root.FlatAppearance.BorderSize = 0;
            this.root.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.root.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.root.ForeColor = System.Drawing.Color.White;
            this.root.Location = new System.Drawing.Point(347, 296);
            this.root.Margin = new System.Windows.Forms.Padding(2);
            this.root.Name = "root";
            this.root.Size = new System.Drawing.Size(65, 60);
            this.root.TabIndex = 24;
            this.root.Text = "ʸ√x";
            this.toolTip1.SetToolTip(this.root, "Y root of x (1st number selected is x)");
            this.root.UseVisualStyleBackColor = false;
            this.root.Click += new System.EventHandler(this.operator_pressed);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(512, 449);
            this.Controls.Add(this.root);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.buttonce);
            this.Controls.Add(this.buttonabs);
            this.Controls.Add(this.buttonfact);
            this.Controls.Add(this.buttonpower);
            this.Controls.Add(this.buttondiv);
            this.Controls.Add(this.buttonplus);
            this.Controls.Add(this.buttonsub);
            this.Controls.Add(this.buttonmul);
            this.Controls.Add(this.buttonequals);
            this.Controls.Add(this.buttonpoint);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.result);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Symbol", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Name = "Form1";
            this.Text = "Kalkulacka";
            this.TransparencyKey = System.Drawing.SystemColors.ActiveCaptionText;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox result;
        public System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        public System.Windows.Forms.Button buttonequals;
        private System.Windows.Forms.Button buttonpoint;
        private System.Windows.Forms.Button button0;
        public System.Windows.Forms.Button buttondiv;
        public System.Windows.Forms.Button buttonplus;
        public System.Windows.Forms.Button buttonsub;
        public System.Windows.Forms.Button buttonmul;
        public System.Windows.Forms.Button buttonpower;
        public System.Windows.Forms.Button buttonfact;
        public System.Windows.Forms.Button buttonabs;
        public System.Windows.Forms.Button buttonce;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button10;
        public System.Windows.Forms.Button button11;
        public System.Windows.Forms.Button root;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

