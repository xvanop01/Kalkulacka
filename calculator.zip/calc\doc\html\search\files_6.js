var searchData=
[
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../Settings_8Designer_8cs.html',1,'']]]
];
