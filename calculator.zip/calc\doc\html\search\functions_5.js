var searchData=
[
  ['minus',['Minus',['../classDanaSimple_1_1OperationsSimple.html#aeedd88ce3743db60d0d5d18d86ae2e23',1,'DanaSimple::OperationsSimple']]],
  ['multi',['Multi',['../classDanaSimple_1_1OperationsSimple.html#a4894b899b1f8b881e6b44ebec8453151',1,'DanaSimple::OperationsSimple']]]
];
