var searchData=
[
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../Settings_8Designer_8cs.html',1,'']]],
  ['stopwatch',['stopWatch',['../classProfiler_1_1ProfilerCounters.html#a39d6525c2377e935b8dbb991dccd319e',1,'Profiler::ProfilerCounters']]],
  ['suma',['Suma',['../classProfiler_1_1Suma.html',1,'Profiler.Suma'],['../classProfiler_1_1Suma.html#a7ac4ae65701886743c0e13e25eedb21c',1,'Profiler.Suma.Suma()']]]
];
