var searchData=
[
  ['deviation',['Deviation',['../classProfiler_1_1Suma.html#ac706fdbb956efae8fca51cb6bdb08bfd',1,'Profiler::Suma']]],
  ['dispose',['Dispose',['../classpokus_1_1Form1.html#a24b23515810a6e52f80e600649e7f5a3',1,'pokus::Form1']]],
  ['div',['Div',['../classDanaSimple_1_1OperationsSimple.html#a687d612438e1e8926213c86393d6949c',1,'DanaSimple::OperationsSimple']]]
];
