var searchData=
[
  ['resources_2edesigner_2ecs',['Resources.Designer.cs',['../Resources_8Designer_8cs.html',1,'']]]
];
