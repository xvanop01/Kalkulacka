var searchData=
[
  ['dana_5fprofessional_2ecs',['dana_professional.cs',['../dana__professional_8cs.html',1,'']]],
  ['dana_5fsimple_2ecs',['dana_simple.cs',['../dana__simple_8cs.html',1,'']]],
  ['danaprofessional',['DanaProfessional',['../classMathLibraryTest_1_1DanaProfessional.html',1,'MathLibraryTest.DanaProfessional'],['../namespaceDanaProfessional.html',1,'DanaProfessional']]],
  ['danasimple',['DanaSimple',['../namespaceDanaSimple.html',1,'']]],
  ['danasimpletest',['DanaSimpleTest',['../classMathLibraryTest_1_1DanaSimpleTest.html',1,'MathLibraryTest']]],
  ['deviation',['Deviation',['../classProfiler_1_1Suma.html#ac706fdbb956efae8fca51cb6bdb08bfd',1,'Profiler::Suma']]],
  ['dispose',['Dispose',['../classpokus_1_1Form1.html#a24b23515810a6e52f80e600649e7f5a3',1,'pokus::Form1']]],
  ['div',['div',['../classProfiler_1_1ProfilerCounters.html#a88a43c3286acaa9a9b31e8da1e6ab08b',1,'Profiler.ProfilerCounters.div()'],['../classDanaSimple_1_1OperationsSimple.html#a687d612438e1e8926213c86393d6949c',1,'DanaSimple.OperationsSimple.Div()']]],
  ['documentation_2edox',['documentation.dox',['../documentation_8dox.html',1,'']]],
  ['documentation_20for_20team_20school_20project_2e',['Documentation for team school project.',['../index.html',1,'']]]
];
