var searchData=
[
  ['operationsprofessional',['OperationsProfessional',['../classDanaProfessional_1_1OperationsProfessional.html',1,'DanaProfessional']]],
  ['operationssimple',['OperationsSimple',['../classDanaSimple_1_1OperationsSimple.html',1,'DanaSimple']]]
];
