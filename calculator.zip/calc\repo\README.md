# Kalkulacka
## IVS 2020 leto - skupinový projekt

### Prostredie
Windows 64bit

### Autori
**_Bystrica_**
- xjurke02  Jurkechová Adriana
- xstefe11  Štefeková Nina
- xsveck00  Švecková Sabína
- xvanop01  Vaňo Peter

### Licencia
Produkt je distribuovaný pod licenciou GPLv1.

### Spustenie z archivu
make all
make run

### Historia na GitHube cez ivskontrola https://github.com/xvanop01/Kalkulacka
