# Kalkulacka
## IVS 2020 leto - skupinový projekt

### Prostredie
Windows 64bit

### Autori
**_Bystrica_**
- xjurke02  Jurkechová Adriana
- xstefe11  Štefeková Nina
- xsveck00  Švecková Sabína
- xvanop01  Vaňo Peter

### Licencia
Produkt je distribuovaný pod licenciou GPLv1.
