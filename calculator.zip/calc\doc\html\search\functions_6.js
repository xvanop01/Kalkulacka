var searchData=
[
  ['plus',['Plus',['../classDanaSimple_1_1OperationsSimple.html#a4db87aef7a77f2c4f4060154c6329db9',1,'DanaSimple::OperationsSimple']]]
];
