var searchData=
[
  ['xi_5f2sum',['xi_2sum',['../classProfiler_1_1Suma.html#ad555897c23ee47308cd9faebabd758ce',1,'Profiler::Suma']]],
  ['xi_5fsum',['xi_sum',['../classProfiler_1_1Suma.html#a517cdab6733ffb45242cad4f7cd1af1c',1,'Profiler::Suma']]]
];
