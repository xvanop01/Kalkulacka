var searchData=
[
  ['factorial',['Factorial',['../classDanaSimple_1_1OperationsSimple.html#ac93a09de0f6e8aa3d0eb36ad895e396a',1,'DanaSimple.OperationsSimple.Factorial()'],['../classProfiler_1_1ProfilerCounters.html#ad05d759e3653355bdd704f5dc275eabf',1,'Profiler.ProfilerCounters.factorial()']]],
  ['form1',['Form1',['../classpokus_1_1Form1.html',1,'pokus.Form1'],['../classpokus_1_1Form1.html#ab64d54a396652470204211a4be1e404a',1,'pokus.Form1.Form1()']]],
  ['form1_2ecs',['Form1.cs',['../Form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../Form1_8Designer_8cs.html',1,'']]]
];
