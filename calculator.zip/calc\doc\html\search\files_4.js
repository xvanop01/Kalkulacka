var searchData=
[
  ['profiler_2eassemblyinfo_2ecs',['Profiler.AssemblyInfo.cs',['../Debug_2netcoreapp3_81_2Profiler_8AssemblyInfo_8cs.html',1,'(Global Namespace)'],['../Release_2netcoreapp3_81_2Profiler_8AssemblyInfo_8cs.html',1,'(Global Namespace)']]],
  ['profiler_2ecs',['Profiler.cs',['../Profiler_8cs.html',1,'']]],
  ['program_2ecs',['Program.cs',['../Program_8cs.html',1,'']]]
];
